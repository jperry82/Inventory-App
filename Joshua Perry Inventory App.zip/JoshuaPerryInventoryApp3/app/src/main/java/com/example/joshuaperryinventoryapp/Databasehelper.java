package com.example.joshuaperryinventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Database helper class for managing SQLite database operations.
 * Handles user authentication and inventory item management.
 */
public class Databasehelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "InventoryApp.db";
    private static final int DATABASE_VERSION = 1;

    // User table and column names
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_USER_ID = "id";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";

    // Inventory table and column names
    private static final String TABLE_INVENTORY = "inventory";
    private static final String COLUMN_ITEM_ID = "item_id";
    private static final String COLUMN_ITEM_NAME = "item_name";
    private static final String COLUMN_ITEM_QUANTITY = "item_quantity";

    public Databasehelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create the users table
        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + " (" +
                COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_USERNAME + " TEXT UNIQUE, " +
                COLUMN_PASSWORD + " TEXT" + ")";
        db.execSQL(CREATE_USERS_TABLE);

        // Create the inventory table
        String CREATE_INVENTORY_TABLE = "CREATE TABLE " + TABLE_INVENTORY + " (" +
                COLUMN_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_ITEM_NAME + " TEXT, " +
                COLUMN_ITEM_QUANTITY + " INTEGER" + ")";
        db.execSQL(CREATE_INVENTORY_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop existing tables and recreate them
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        onCreate(db);
    }

    /**
     * Adds a new user to the database.
     *
     * @param username The user's username
     * @param password The user's password
     * @return true if the user was added successfully, false otherwise
     */
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);
        db.close();
        return result != -1; // Return true if insertion was successful
    }

    /**
     * Checks if a user exists in the database with the provided credentials.
     *
     * @param username The user's username
     * @param password The user's password
     * @return true if the user exists, false otherwise
     */
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_USER_ID};  // We only need the ID column for validation
        String selection = COLUMN_USERNAME + " = ? AND " + COLUMN_PASSWORD + " = ?";
        String[] selectionArgs = {username, password};

        Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);
        int cursorCount = cursor.getCount();
        cursor.close();
        db.close();
        return cursorCount > 0;  // Return true if user exists
    }

    /**
     * Checks if an inventory item with the same name already exists in the database.
     *
     * @param itemName The name of the item
     * @return true if an item with the same name exists, false otherwise
     */
    public boolean itemExists(String itemName) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_ITEM_NAME};
        String selection = COLUMN_ITEM_NAME + " = ?";
        String[] selectionArgs = {itemName};

        Cursor cursor = db.query(TABLE_INVENTORY, columns, selection, selectionArgs, null, null, null);
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return exists;
    }

    /**
     * Adds a new inventory item to the database.
     *
     * @param name The name of the item
     * @param quantity The quantity of the item
     * @return true if the item was added successfully, false otherwise
     */
    public boolean addItem(String name, int quantity) {
        if (itemExists(name)) {
            return false; // Item with the same name already exists
        }

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_NAME, name);
        values.put(COLUMN_ITEM_QUANTITY, quantity);

        long result = db.insert(TABLE_INVENTORY, null, values);
        db.close();
        return result != -1; // Return true if insertion was successful
    }

    /**
     * Retrieves all inventory items from the database.
     *
     * @return A list of all inventory items
     */
    public List<InventoryItem> getAllItems() {
        List<InventoryItem> itemList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_INVENTORY, null);
        if (cursor.moveToFirst()) {
            do {
                int idIndex = cursor.getColumnIndex(COLUMN_ITEM_ID);
                int nameIndex = cursor.getColumnIndex(COLUMN_ITEM_NAME);
                int quantityIndex = cursor.getColumnIndex(COLUMN_ITEM_QUANTITY);

                if (idIndex != -1 && nameIndex != -1 && quantityIndex != -1) {
                    InventoryItem item = new InventoryItem(
                            cursor.getInt(idIndex),
                            cursor.getString(nameIndex),
                            cursor.getInt(quantityIndex)
                    );
                    itemList.add(item);
                }
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return itemList;
    }

    /**
     * Updates the quantity of an inventory item in the database.
     *
     * @param itemId      The ID of the item to update
     * @param newQuantity The new quantity of the item
     * @return true if the item quantity was updated successfully, false otherwise
     */
    public boolean updateItemQuantity(int itemId, int newQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_QUANTITY, newQuantity);

        int rowsAffected = db.update(TABLE_INVENTORY, values, COLUMN_ITEM_ID + " = ?", new String[]{String.valueOf(itemId)});
        db.close();
        return rowsAffected > 0; // Return true if one or more rows were updated
    }

    /**
     * Deletes an inventory item from the database by ID.
     *
     * @param itemId The ID of the item to delete
     * @return true if the item was deleted successfully, false otherwise
     */
    public boolean deleteItem(int itemId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete(TABLE_INVENTORY, COLUMN_ITEM_ID + " = ?", new String[]{String.valueOf(itemId)});
        db.close();
        return result > 0; // Return true if one or more rows were deleted
    }
}
