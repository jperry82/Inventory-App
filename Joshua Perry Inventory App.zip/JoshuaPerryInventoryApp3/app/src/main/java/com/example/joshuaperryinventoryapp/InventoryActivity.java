package com.example.joshuaperryinventoryapp;

import android.Manifest;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.List;

public class InventoryActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 1;
    private boolean isSmsEnabled = false; // Track the SMS state
    private Databasehelper databaseHelper;
    private InventoryAdapter adapter;
    private List<InventoryItem> itemList;
    private GridView gridView;
    private Button addItemButton;
    private Button smsToggleButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        databaseHelper = new Databasehelper(this);
        addItemButton = findViewById(R.id.add_item_button);
        smsToggleButton = findViewById(R.id.sms_permission_button);
        gridView = findViewById(R.id.inventory_grid);

        loadItems();
        updateSmsButtonLabel();

        addItemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAddItemDialog();
            }
        });

        smsToggleButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSmsToggleDialog();
            }
        });
    }

    /**
     * Loads all items from the database and sets them into the GridView using the InventoryAdapter.
     */
    private void loadItems() {
        itemList = databaseHelper.getAllItems();
        adapter = new InventoryAdapter(this, itemList);
        gridView.setAdapter(adapter);
    }

    /**
     * Shows a dialog that allows the user to add a new inventory item.
     */
    private void showAddItemDialog() {
        // Your implementation for the Add Item dialog
    }

    /**
     * Updates the label of the SMS toggle button based on whether SMS is enabled or disabled.
     */
    private void updateSmsButtonLabel() {
        if (isSmsEnabled) {
            smsToggleButton.setText("Disable SMS");
        } else {
            smsToggleButton.setText("Enable SMS");
        }
    }

    /**
     * Shows a dialog to prompt the user to enable or disable SMS.
     */
    private void showSmsToggleDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(isSmsEnabled ? "Disable SMS" : "Enable SMS");
        builder.setMessage(isSmsEnabled ? "Do you want to disable SMS notifications?" : "Do you want to enable SMS notifications?");

        builder.setPositiveButton(isSmsEnabled ? "Disable" : "Enable", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (isSmsEnabled) {
                    isSmsEnabled = false;
                    Toast.makeText(InventoryActivity.this, "SMS disabled", Toast.LENGTH_SHORT).show();
                } else {
                    checkAndRequestSmsPermission();
                }
                updateSmsButtonLabel();
            }
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    /**
     * Checks if SMS permission is granted; if not, it requests the permission from the user.
     */
    private void checkAndRequestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        } else {
            isSmsEnabled = true;
            Toast.makeText(this, "SMS enabled", Toast.LENGTH_SHORT).show();
            updateSmsButtonLabel();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                isSmsEnabled = true;
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
            updateSmsButtonLabel();
        }
    }
}
