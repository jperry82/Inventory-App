package com.example.joshuaperryinventoryapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/**
 * Activity that handles SMS permission requests and sends SMS notifications.
 * If the permission is denied, the app continues to function without the SMS feature.
 */
public class SmsPermissionActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 101;
    private Button enableSmsButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        // Initialize the enable SMS button
        enableSmsButton = findViewById(R.id.enable_sms_button);

        // Set click listener for the enable SMS button
        enableSmsButton.setOnClickListener(v -> {
            if (checkSmsPermission()) {
                // Permission granted, send the SMS notification
                sendSmsNotification("Inventory Alert: Low stock on item(s)!");
            } else {
                // Permission not granted, request permission
                requestSmsPermission();
            }
        });
    }

    /**
     * Checks if the SEND_SMS permission is granted.
     *
     * @return true if the permission is granted, false otherwise
     */
    private boolean checkSmsPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    /**
     * Requests the SEND_SMS permission from the user.
     */
    private void requestSmsPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
    }

    /**
     * Sends an SMS notification to a predefined phone number.
     *
     * @param message The message to be sent via SMS
     */
    private void sendSmsNotification(String message) {
        String phoneNumber = "1234567890"; // Replace with a valid phone number

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS sent successfully!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "SMS failed to send.", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Handles the result of the SMS permission request.
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, send the SMS notification
                sendSmsNotification("Inventory Alert: Low stock on item(s)!");
            } else {
                // Permission denied, continue without SMS functionality
                Toast.makeText(this, "SMS permission denied. The app will continue to function without SMS notifications.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
