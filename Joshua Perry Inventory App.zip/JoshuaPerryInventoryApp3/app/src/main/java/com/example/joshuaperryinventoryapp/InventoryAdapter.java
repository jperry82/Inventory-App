package com.example.joshuaperryinventoryapp;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class InventoryAdapter extends BaseAdapter {

    private Context context;
    private List<InventoryItem> inventoryItemList;
    private Databasehelper databaseHelper;

    public InventoryAdapter(Context context, List<InventoryItem> inventoryItemList) {
        this.context = context;
        this.inventoryItemList = inventoryItemList;
        this.databaseHelper = new Databasehelper(context);
    }

    @Override
    public int getCount() {
        return inventoryItemList.size();
    }

    @Override
    public Object getItem(int position) {
        return inventoryItemList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return inventoryItemList.get(position).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.inventory_item, parent, false);
            viewHolder = new ViewHolder();
            viewHolder.itemName = convertView.findViewById(R.id.item_name);
            viewHolder.itemQuantity = convertView.findViewById(R.id.item_quantity);
            viewHolder.adjustQtyButton = convertView.findViewById(R.id.adjust_qty_button);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        InventoryItem item = inventoryItemList.get(position);
        viewHolder.itemName.setText(item.getName());
        viewHolder.itemQuantity.setText(String.valueOf(item.getQuantity()));

        viewHolder.adjustQtyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAdjustQuantityDialog(item);
            }
        });

        return convertView;
    }

    private void showAdjustQuantityDialog(final InventoryItem item) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Adjust Quantity");

        // Set up the input field for the quantity adjustment
        final EditText input = new EditText(context);
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        input.setHint("Enter quantity to adjust");
        builder.setView(input);

        // Set up the Add button
        builder.setPositiveButton("Add", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String qtyStr = input.getText().toString().trim();
                if (!qtyStr.isEmpty()) {
                    int qtyToAdjust = Integer.parseInt(qtyStr);
                    if (qtyToAdjust > 0) {
                        int newQuantity = item.getQuantity() + qtyToAdjust;
                        item.setQuantity(newQuantity);
                        databaseHelper.updateItemQuantity(item.getId(), newQuantity);
                        notifyDataSetChanged();
                        Toast.makeText(context, "Added " + qtyToAdjust + " items", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(context, "Invalid quantity", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        // Set up the Subtract button
        builder.setNegativeButton("Subtract", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String qtyStr = input.getText().toString().trim();
                if (!qtyStr.isEmpty()) {
                    int qtyToAdjust = Integer.parseInt(qtyStr);
                    if (qtyToAdjust > 0 && qtyToAdjust <= item.getQuantity()) {
                        int newQuantity = item.getQuantity() - qtyToAdjust;
                        if (newQuantity >= 0) {
                            item.setQuantity(newQuantity);
                            databaseHelper.updateItemQuantity(item.getId(), newQuantity);
                            notifyDataSetChanged();
                            Toast.makeText(context, "Subtracted " + qtyToAdjust + " items", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(context, "Cannot subtract more than available quantity", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(context, "Invalid quantity", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        // Set up the Delete button
        builder.setNeutralButton("Delete", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                databaseHelper.deleteItem(item.getId());
                inventoryItemList.remove(item);
                notifyDataSetChanged();
                Toast.makeText(context, "Item deleted", Toast.LENGTH_SHORT).show();
            }
        });

        builder.show();
    }

    private static class ViewHolder {
        TextView itemName;
        TextView itemQuantity;
        Button adjustQtyButton;
    }
}
